# Gene X Labs — Deploy Package

Source code: https://github.com/saloprj/genex

---

## Local Development

**Prerequisites:** Node.js 18+, Docker, npm

```bash
chmod +x local-setup.sh
./local-setup.sh
```

Opens at http://localhost:3000
Log in with any email — Supabase auth is bypassed locally automatically.

---

## Production Deploy (existing server: 65.109.65.205)

**Prerequisites on your machine:** rsync, ssh access to the server

### Every deploy (code update)

```bash
# 1. Sync code — NEVER sync .env or images (they live on server permanently)
rsync -av \
  --exclude='node_modules' --exclude='.next' \
  --exclude='.env' --exclude='.env.local' \
  --exclude='*.png' --exclude='*.jpg' \
  ./ ubuntu@65.109.65.205:/home/ubuntu/genex/ -e "ssh -p 25650"

# 2. Sync public assets separately (logos, product images)
rsync -av ./public/ ubuntu@65.109.65.205:/home/ubuntu/genex/public/ -e "ssh -p 25650"

# 3. Build ONLY the web image (never build postgres)
ssh -p 25650 ubuntu@65.109.65.205 "cd /home/ubuntu/genex && docker compose build web"

# 4. Recreate ONLY web container — --no-deps is CRITICAL (never touch postgres)
ssh -p 25650 ubuntu@65.109.65.205 "docker rm -f genexpep-web && cd /home/ubuntu/genex && docker compose up -d --no-deps web"

# 5. Verify
ssh -p 25650 ubuntu@65.109.65.205 "sleep 8 && curl -s -o /dev/null -w 'HTTP %{http_code}\n' http://localhost:3012/shop"
```

### ⚠️ NEVER do this (causes outage)

```bash
# BAD — recreates network, disconnects postgres from web container
docker compose up -d web           # missing --no-deps
docker compose up -d               # starts everything, breaks network
docker compose up -d --no-deps web # without removing old container first causes name conflict
```

---

## First-time server setup (new server)

### 1. SSH into server and clone repo
```bash
ssh -p 25650 ubuntu@YOUR_SERVER
git clone git@github.com:saloprj/genex.git /home/ubuntu/genex
```

### 2. Copy .env to the server (one time only — never overwritten by deploys)
```bash
scp -P 25650 .env ubuntu@YOUR_SERVER:/home/ubuntu/genex/.env
```

### 3. Copy public assets
```bash
rsync -av ./public/ ubuntu@YOUR_SERVER:/home/ubuntu/genex/public/ -e "ssh -p 25650"
```

### 4. Start full stack for the first time
```bash
ssh -p 25650 ubuntu@YOUR_SERVER "cd /home/ubuntu/genex && docker compose up -d"
```
This starts both postgres and web. Postgres initializes with `POSTGRES_PASSWORD` from `.env`.

### 5. Run DB migrations and seed
```bash
ssh -p 25650 ubuntu@YOUR_SERVER \
  "docker exec genexpep-web npx prisma db push --skip-generate && \
   docker exec genexpep-web npx prisma db seed"
```

### 6. Verify
```bash
curl -s -o /dev/null -w '%{http_code}' http://YOUR_SERVER:3012/shop
# Should return 307 (redirect to login) = working
```

---

## Troubleshooting

### DB auth error after deploy
If you see `Authentication failed against database server` in logs:

```bash
# Option 1: postgres password out of sync — reset it
ssh -p 25650 ubuntu@SERVER \
  "docker exec genexpep-postgres psql -U genexpep -d genexpep \
   -c \"ALTER USER genexpep PASSWORD 'YOUR_POSTGRES_PASSWORD';\""

# Option 2: postgres on wrong network — reconnect with alias
ssh -p 25650 ubuntu@SERVER \
  "docker network disconnect genex_internal genexpep-postgres; \
   docker network connect --alias postgres genex_internal genexpep-postgres; \
   docker restart genexpep-web"
```

### Check logs
```bash
ssh -p 25650 ubuntu@SERVER "docker logs genexpep-web --tail=50"
```

---

## Files in this package

| File | Purpose |
|------|---------|
| `.env` | Production credentials (Supabase, Stripe, Dexpay) — keep secret |
| `.env.local` | Local dev config (local Docker postgres, no Supabase needed) |
| `local-setup.sh` | One-command local dev setup |
| `deploy.sh` | Automated deploy script for any server |
| `README.md` | This file |

---

## Architecture

- **App:** Next.js 14 in Docker container (`genexpep-web`) on port 3012
- **DB:** PostgreSQL 16 in Docker container (`genexpep-postgres`)
- **Auth:** Supabase (passwordless OTP via email)
- **Payments:** Stripe (card) + DexPay (crypto — ETH, BTC, USDT TRC20/ERC20/BEP20)
- **CDN:** Cloudflare proxies genexpep.com → server:3012
- **Network:** Both containers on `genex_internal` Docker bridge network
