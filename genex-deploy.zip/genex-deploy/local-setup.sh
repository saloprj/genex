#!/bin/bash
# ============================================================
# Gene X Labs — Local Development Setup
# Requires: Node.js 18+, Docker, npm
# ============================================================
set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

echo "==> Setting up Gene X Labs locally ..."

# 1. Clone if needed
if [ ! -f "$PROJECT_DIR/package.json" ]; then
  echo "==> Cloning repository ..."
  git clone git@github.com:saloprj/genex.git "$PROJECT_DIR"
fi

cd "$PROJECT_DIR"

# 2. Place env files
echo "==> Placing .env.local ..."
cp "$SCRIPT_DIR/.env.local" .env.local

# 3. Install dependencies
echo "==> Installing dependencies ..."
npm install

# 4. Start local postgres via Docker
echo "==> Starting local Postgres on port 5434 ..."
docker run -d \
  --name genex-local-postgres \
  -e POSTGRES_USER=genexpep \
  -e POSTGRES_PASSWORD=G3n3xP3p!Pr0d2026 \
  -e POSTGRES_DB=genexpep \
  -p 5434:5432 \
  postgres:16-alpine || echo "(container already running)"

echo "==> Waiting for Postgres to be ready ..."
sleep 3

# 5. Push schema & seed
echo "==> Pushing DB schema ..."
npm run db:push

echo "==> Seeding database ..."
npm run db:seed

# 6. Done
echo ""
echo "✓ Setup complete!"
echo ""
echo "  Start dev server:  npm run dev"
echo "  App URL:           http://localhost:3000"
echo "  Dev login:         dev@genexlabs.com (auto-bypasses Supabase auth)"
echo "  Admin panel:       http://localhost:3000/admin"
echo ""
echo "  DB Studio:         npm run db:studio"
echo "  Stop postgres:     docker stop genex-local-postgres"
