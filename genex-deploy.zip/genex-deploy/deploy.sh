#!/bin/bash
# ============================================================
# Gene X Labs — Production Deploy Script
# Usage: ./deploy.sh [user@host] [ssh_port]
# Example: ./deploy.sh ubuntu@65.109.65.205 25650
# ============================================================
set -e

HOST=${1:-"ubuntu@65.109.65.205"}
PORT=${2:-25650}
REMOTE_DIR="/home/ubuntu/genex"

echo "==> Syncing code to $HOST:$REMOTE_DIR ..."
rsync -av \
  --exclude='node_modules' \
  --exclude='.next' \
  --exclude='.env' \
  --exclude='.env.local' \
  --exclude='*.png' \
  --exclude='*.jpg' \
  --exclude='*.jpeg' \
  "$(dirname "$0")/../" \
  "$HOST:$REMOTE_DIR/" \
  -e "ssh -p $PORT"

echo "==> Syncing public assets (images/logos) ..."
rsync -av \
  "$(dirname "$0")/../public/" \
  "$HOST:$REMOTE_DIR/public/" \
  -e "ssh -p $PORT"

echo "==> Building Docker image ..."
ssh -p "$PORT" "$HOST" "cd $REMOTE_DIR && docker compose build web"

echo "==> Restarting web container (postgres untouched) ..."
ssh -p "$PORT" "$HOST" "docker rm -f genexpep-web; cd $REMOTE_DIR && docker compose up -d --no-deps web"

echo "==> Reconnecting postgres DNS alias ..."
ssh -p "$PORT" "$HOST" "
  docker network disconnect genex_internal genexpep-postgres 2>/dev/null || true
  docker network connect --alias postgres genex_internal genexpep-postgres
"

echo "==> Waiting for app to start ..."
sleep 10

echo "==> Running DB migrations ..."
ssh -p "$PORT" "$HOST" "docker exec genexpep-web npx prisma db push --skip-generate 2>&1 || true"

echo "==> Verifying ..."
STATUS=$(ssh -p "$PORT" "$HOST" "curl -s -o /dev/null -w '%{http_code}' http://localhost:3012/")
echo "HTTP status: $STATUS"

if [ "$STATUS" = "200" ] || [ "$STATUS" = "307" ]; then
  echo "✓ Deploy successful!"
else
  echo "✗ Something may be wrong — check: ssh -p $PORT $HOST 'docker logs genexpep-web --tail=30'"
fi
